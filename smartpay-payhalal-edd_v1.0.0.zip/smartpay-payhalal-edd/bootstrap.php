<?php

require_once __DIR__ . '/vendor/autoload.php';

use SmartPayPayhalalEdd\PayHalalPaymentGateway;

// load the instance of the plugin
PayHalalPaymentGateway::instance();
